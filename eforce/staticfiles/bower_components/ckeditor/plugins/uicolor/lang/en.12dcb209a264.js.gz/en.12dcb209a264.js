﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","en",{title:"UI Color Picker",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Predefined color sets",config:"Paste this string into your config.js file"});