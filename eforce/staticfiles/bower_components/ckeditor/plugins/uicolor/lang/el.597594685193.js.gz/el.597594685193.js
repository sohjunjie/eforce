﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","el",{title:"Διεπαφή Επιλογής Χρωμάτων",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Προκαθορισμένα σύνολα χρωμάτων",config:"Επικολλήστε αυτό το κείμενο στο αρχείο config.js"});