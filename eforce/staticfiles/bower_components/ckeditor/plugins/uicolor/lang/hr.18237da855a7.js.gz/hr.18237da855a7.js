﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","hr",{title:"UI odabir boja",options:"Opcije boja",highlight:"Označi",selected:"Odabrana boja",predefined:"Već postavljeni setovi boja",config:"Zalijepite ovaj tekst u Vašu config.js datoteku."});