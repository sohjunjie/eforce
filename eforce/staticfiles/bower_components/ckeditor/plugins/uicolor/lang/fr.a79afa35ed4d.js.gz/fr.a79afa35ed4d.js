﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","fr",{title:"Sélecteur de couleur",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Palettes de couleurs prédéfinies",config:"Collez ce texte dans votre fichier config.js"});