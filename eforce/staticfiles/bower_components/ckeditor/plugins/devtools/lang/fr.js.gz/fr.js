﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","fr",{title:"Informations sur l'élément",dialogName:"Nom de la boîte de dialogue",tabName:"Nom de l'onglet",elementId:"ID de l'élément",elementType:"Type de l'élément"});