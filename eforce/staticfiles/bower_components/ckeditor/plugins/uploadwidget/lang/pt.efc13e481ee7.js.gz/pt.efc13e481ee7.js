﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","pt",{abort:"Carregamento cancelado pelo utilizador.",doneOne:"Ficheiro carregado com sucesso.",doneMany:"Successfully uploaded %1 files.",uploadOne:"Uploading file ({percentage}%)...",uploadMany:"Uploading files, {current} of {max} done ({percentage}%)..."});